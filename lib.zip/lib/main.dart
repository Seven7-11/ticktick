import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart'; // ✅ เพิ่ม
import 'firebase_options.dart'; // ✅ เพิ่ม (ถ้ามีไฟล์นี้อยู่แล้ว)
import 'package:ticktick/login_page_v2.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized(); // ✅ เพิ่ม
  await Firebase.initializeApp(               // ✅ เพิ่ม
    options: DefaultFirebaseOptions.currentPlatform,
  );

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: LoginPage(
        isDarkMode: false,
        onThemeChanged: (_) {},
      ),
    );
  }
}
